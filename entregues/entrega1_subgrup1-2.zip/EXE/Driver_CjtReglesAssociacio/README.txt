Driver CjtReglesAssociacio
En aquest driver es proven totes les funcionalitats de la classe CjtReglesAssociacio.

Es fa un joc de proves per provar totes les funcionalitats i dels errors que es podrien haver-hi.

input_jprova1.txt:
Prova totes les funcionalitats de la classe que funcionin correctament i com es esperat. A mes, comprova que es tornin els missatges derror correctes:
 - Es fa el test de la Consutructora per defecte
 - Es fa el test de la Constructora passant-li un conjunt de Regles.
 - Es crea un conjunt de regles associacions
 - Consulta el conjunt de Regles associacions
 - Consulta una Regla Associacio
 - Actualitzar una Regla Associacio
 - Consulta llista de Regles de Associacions
 - Actualitzar una Regla Associacio que no existeix
 - Eliminar una regla Associacio
 - Consulta el conjunt de Regles Associacio
 - Eliminar una regla associacio que no existeix
 - Pasar opcions incorrectes en la constructora
 - Sortir del programa.


Per executar el driver, utilitzar la comanda: java -jar Driver_CjtReglesAssociacio.jar

Per utilitzar el joc de proves 1: java -jar Driver_CjtReglesAssociacio.jar < input_jprova1.txt