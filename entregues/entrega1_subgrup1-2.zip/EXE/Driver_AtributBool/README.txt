DriverAtributBool
En aquest driver es proven totes les funcionalitats de la classe AtributBool.

Hi ha inclos un joc de proves anomenat: input_jproves.txt

Prova totes les funcionalitats de la classe que funcionin correctament i com es esperat detectant els possibles errors:
 - Crea un atribut amb nom atributbool de tipus String i despres de tipus float per a que retorni error de tipus
 - Crea un atribut amb nom atributbool de tipus boolean.
 - Crea un atribut amb nom atributbool de tipus boolean amb valor fals="suspes" i valor cert="aprovat"
 - Consulta el nom amb el getter
 - Consulta el tipus amb el getter
 - Canvia el nom del atribut amb el setter
 - Consulta el tipus de l'atribut amb el setter
 - Comprova el setter d'un parell de valors fals i cert respectivament
 - Consulta si un valor forma part d'un atribut, es a dir, si es considerat cert o fals
 - Comprova si el valor introduit es cert per a l'atribut o be fals ja que nomes hi han dos valors possibles per a un atributBool
 - Consulta els valors fals i cert d'un atribut amb un getter

Per executar el driver, utilitzar la comanda: java -jar Driver_AtributBool.jar

Per utilitzar el joc de proves: java -jar Driver_AtributBool.jar < input_jproves.txt
