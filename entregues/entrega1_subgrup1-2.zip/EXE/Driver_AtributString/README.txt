DriverAtributString
En aquest driver es proven totes les funcionalitats de la classe AtributString.

Hi ha inclos un joc de proves anomenat: input_jproves.txt

Prova totes les funcionalitats de la classe que funcionin correctament i com es esperat detectant els possibles errors:
 - Crea un atribut amb nom atributstring de tipus float, despres de tipus boolean i numeric per a que retorni error de tipus
 - Crea un atribut amb nom atributstring de tipus String.

 - Crea un atribut amb nom atributstring de tipus String amb valors possibles Carles i Pere
 - Consulta el nom amb el getter
 - Consulta el tipus amb el getter
 - Canvia el nom del atribut amb el setter
 - Canvia el tipus de l'atribut amb el setter
 - Comprova si un valor erroni hi es com possible i despres un de correcte
 - Comprova el preproces de l'atribut. (Com els valors possibles son el propi preproces no fa res mes)
 - Afegeix un valor possible a l'atribut
 - Assigna una llista de valors possibles a l'atribut
 - Obte la llista de valors possibles de l'atribut

Per executar el driver, utilitzar la comanda: java -jar Driver_AtributString.jar

Per utilitzar el joc de proves: java -jar Driver_AtributString.jar < input_jproves.txt
