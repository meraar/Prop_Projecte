DriverCjtAtributs
En aquest driver es proven totes les funcionalitats de la classe CjtAtributs.

Hi ha inclos un joc de proves anomenat: input_jproves.txt

Prova totes les funcionalitats de la classe que funcionin correctament i com es esperat detectant els possibles errors:
 - Crea un conjunt d'atributs buit
 - Crea un conjunt d'atributs amb atributs.
 - Es modifica un atribut del conjunt.
 - S'elimina un atribut del conjunt.

Per executar el driver, utilitzar la comanda: java -jar Driver_CjtAtributs.jar

Per utilitzar el joc de proves: java -jar Driver_CjtAtributs.jar < input_jproves.txt
