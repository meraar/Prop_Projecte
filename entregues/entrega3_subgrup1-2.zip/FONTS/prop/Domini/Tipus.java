package prop.Domini;

/**
 * @author Carles Capilla
 */
public enum Tipus {
        BOOL,
        STRING,
        FLOAT

}
